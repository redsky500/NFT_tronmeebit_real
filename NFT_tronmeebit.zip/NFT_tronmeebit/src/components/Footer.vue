<template>
  <div class="footer" id="footer">
    <!-- Footer -->
    <footer class="page-footer font-small mdb-color pt-4">
      <!-- Footer Links -->
      <p class="footer-underline"></p>
      <div class="container text-center text-md-left">
        <!-- Grid row -->
        <div class="row d-flex align-items-center">
          <!-- Grid column -->
          <div class="col-md-7 col-lg-8 mb-3">
            <!--Copyright-->
            <img class="footer-logo-size" src="../assets/logoTM2.png" />
            <span class="text-center text-md-left pl-4">
              © Copyright 2021 - TronMeebits
            </span>
          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-md-5 col-lg-4 ml-lg-0">
            <!-- Social buttons -->
            <div class="text-center text-md-right">
              <ul class="list-unstyled list-inline">
                <li class="list-inline-item">
                  <a class="btn-floating btn-sm rgba-white-slight mx-1">
                    <i class="fab fa-facebook-f"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="btn-floating btn-sm rgba-white-slight mx-1">
                    <i class="fab fa-twitter"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="btn-floating btn-sm rgba-white-slight mx-1">
                    <i class="fab fa-google-plus-g"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="btn-floating btn-sm rgba-white-slight mx-1">
                    <i class="fab fa-linkedin-in"></i>
                  </a>
                </li>
                <!-- <li>
                  <i class="fa fa-reddit fa-lg"></i>
                </li> -->
              </ul>
            </div>
          </div>
          <!-- Grid column -->
        </div>
        <!-- Grid row -->
      </div>
      <!-- Footer Links -->
    </footer>
    <!-- Footer -->
  </div>
</template>
<style scoped>
#footer {
  margin-bottom: 0px;
}
.footer-logo-size {
  width: 55px;
  height: 45px;
}
.footer {
  border-top: 1px solid rgba(0, 0, 0, 0.1);
}
.footer-underline {
  border-bottom: 1px solid rgba(0, 0, 0, 0.1);
  padding-bottom: 20px;
  padding-top: 60px;
}
</style>