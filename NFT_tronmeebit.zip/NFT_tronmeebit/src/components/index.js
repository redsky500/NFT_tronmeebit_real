import NavBar from './NavBar.vue'
import Footer from './Footer.vue'
import ScrollTopArrow from './ScrollTopComponent.vue'
export { NavBar, Footer, ScrollTopArrow}